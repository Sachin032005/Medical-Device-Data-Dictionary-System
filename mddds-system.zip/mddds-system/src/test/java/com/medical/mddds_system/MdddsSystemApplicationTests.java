package com.medical.mddds_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MdddsSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
