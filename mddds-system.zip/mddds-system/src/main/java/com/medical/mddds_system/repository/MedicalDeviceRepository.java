package com.medical.mddds_system.repository;

import com.medical.mddds_system.entity.MedicalDevice;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MedicalDeviceRepository extends JpaRepository<MedicalDevice, Long> {

    List<MedicalDevice> findByDeviceNameContainingIgnoreCase(String deviceName);

    List<MedicalDevice> findByManufacturerNameContainingIgnoreCase(String keyword);}