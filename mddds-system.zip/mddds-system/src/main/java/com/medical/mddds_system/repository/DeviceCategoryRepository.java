package com.medical.mddds_system.repository;

import com.medical.mddds_system.entity.DeviceCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DeviceCategoryRepository extends JpaRepository<DeviceCategory, Long> {

    Optional<DeviceCategory> findByDictionaryId(String dictionaryId);

    Optional<DeviceCategory> findByFieldName(String fieldName);

}