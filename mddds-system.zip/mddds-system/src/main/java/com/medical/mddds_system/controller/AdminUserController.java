package com.medical.mddds_system.controller;

import com.medical.mddds_system.dto.RegisterRequest;
import com.medical.mddds_system.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/users")
public class AdminUserController {

    private final UserService userService;

    public AdminUserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public String listUsers(Model model) {
        model.addAttribute("users", userService.getAllUsers());
        model.addAttribute("registerRequest", new RegisterRequest());
        return "admin-users";
    }

    @PostMapping("/add")
    public String addUser(@ModelAttribute RegisterRequest request) {
        userService.registerUser(request);
        return "redirect:/admin/users";
    }

    @PostMapping("/toggle/{id}")
    public String toggleUser(@PathVariable Long id) {
        userService.toggleUserStatus(id);
        return "redirect:/admin/users";
    }

    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return "redirect:/admin/users";
    }
}