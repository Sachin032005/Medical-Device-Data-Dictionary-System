package com.medical.mddds_system.controller;

import com.medical.mddds_system.entity.DeviceCategory;
import com.medical.mddds_system.service.DeviceCategoryService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/categories")
public class DeviceCategoryController {

    private final DeviceCategoryService service;

    public DeviceCategoryController(DeviceCategoryService service) {
        this.service = service;
    }

    // LIST ALL DICTIONARY FIELDS
    @GetMapping
    public String listCategories(Model model) {
        model.addAttribute("categories", service.getAllCategories());
        return "category-list";
    }

    // OPEN ADD FORM
    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("category", new DeviceCategory());
        return "category-form";
    }

    // SAVE (ADD OR UPDATE)
    @PostMapping("/save")
    public String saveCategory(@ModelAttribute DeviceCategory category, Model model) {

        if (category.getId() != null) {

            DeviceCategory existing = service.getCategoryById(category.getId());

            existing.setFieldName(category.getFieldName());
            existing.setDescription(category.getDescription());
            existing.setDataType(category.getDataType());
            existing.setAllowedValues(category.getAllowedValues());
            existing.setUnitOfMeasure(category.getUnitOfMeasure());
            existing.setMandatory(category.getMandatory());
            existing.setValidationRules(category.getValidationRules());
            existing.setStandardReference(category.getStandardReference());
            existing.setRemarks(category.getRemarks());

            service.saveCategory(existing);

        } else {

            if (service.getByDictionaryId(category.getDictionaryId()).isPresent()) {

                model.addAttribute("category", category);
                model.addAttribute("error", "Dictionary ID already exists!");

                return "category-form";
            }

            service.saveCategory(category);
        }

        return "redirect:/admin/categories";
    }

    // OPEN EDIT FORM
    @GetMapping("/edit/{id}")
    public String editCategory(@PathVariable Long id, Model model) {

        DeviceCategory category = service.getCategoryById(id);

        model.addAttribute("category", category);

        return "category-form";
    }

    // DELETE FIELD
    @GetMapping("/delete/{id}")
    public String deleteCategory(@PathVariable Long id) {

        service.deleteCategory(id);

        return "redirect:/admin/categories";
    }
}