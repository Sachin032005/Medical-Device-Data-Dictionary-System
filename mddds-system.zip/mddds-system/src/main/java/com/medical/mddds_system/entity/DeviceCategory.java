package com.medical.mddds_system.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "device_categories")
public class DeviceCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "dictionary_id", unique = true, nullable = false)
    private String dictionaryId;

    @Column(name = "field_name", nullable = false)
    private String fieldName;

    @Column(name = "description", length = 1000)
    private String description;

    @Column(name = "data_type")
    private String dataType;

    @Column(name = "allowed_values", length = 1000)
    private String allowedValues;

    @Column(name = "unit_of_measure")
    private String unitOfMeasure;

    @Column(name = "mandatory")
    private Boolean mandatory;

    @Column(name = "validation_rules", length = 1000)
    private String validationRules;

    @Column(name = "standard_reference")
    private String standardReference;

    @Column(name = "remarks", length = 1000)
    private String remarks;

    // Default Constructor
    public DeviceCategory() {
    }

    // Parameterized Constructor
    public DeviceCategory(String dictionaryId,
                          String fieldName,
                          String description,
                          String dataType,
                          String allowedValues,
                          String unitOfMeasure,
                          Boolean mandatory,
                          String validationRules,
                          String standardReference,
                          String remarks) {

        this.dictionaryId = dictionaryId;
        this.fieldName = fieldName;
        this.description = description;
        this.dataType = dataType;
        this.allowedValues = allowedValues;
        this.unitOfMeasure = unitOfMeasure;
        this.mandatory = mandatory;
        this.validationRules = validationRules;
        this.standardReference = standardReference;
        this.remarks = remarks;
    }

    // ===== Getters & Setters =====

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDictionaryId() {
        return dictionaryId;
    }

    public void setDictionaryId(String dictionaryId) {
        this.dictionaryId = dictionaryId;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getAllowedValues() {
        return allowedValues;
    }

    public void setAllowedValues(String allowedValues) {
        this.allowedValues = allowedValues;
    }

    public String getUnitOfMeasure() {
        return unitOfMeasure;
    }

    public void setUnitOfMeasure(String unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }

    public Boolean getMandatory() {
        return mandatory;
    }

    public void setMandatory(Boolean mandatory) {
        this.mandatory = mandatory;
    }

    public String getValidationRules() {
        return validationRules;
    }

    public void setValidationRules(String validationRules) {
        this.validationRules = validationRules;
    }

    public String getStandardReference() {
        return standardReference;
    }

    public void setStandardReference(String standardReference) {
        this.standardReference = standardReference;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}