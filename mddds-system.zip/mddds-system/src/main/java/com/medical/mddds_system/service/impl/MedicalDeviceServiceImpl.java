package com.medical.mddds_system.service.impl;

import com.medical.mddds_system.entity.MedicalDevice;
import com.medical.mddds_system.repository.MedicalDeviceRepository;
import com.medical.mddds_system.service.MedicalDeviceService;
import com.medical.mddds_system.service.AuditService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MedicalDeviceServiceImpl implements MedicalDeviceService {

    private final MedicalDeviceRepository repository;
    private final AuditService auditService;
    public MedicalDeviceServiceImpl(MedicalDeviceRepository repository,
            AuditService auditService) {
this.repository = repository;
this.auditService = auditService;
}

    @Override
    public void saveDevice(MedicalDevice device, String username) {

        boolean isNew = (device.getId() == null);

        device.setCreatedBy(username);
        device.setUpdatedAt(java.time.LocalDateTime.now());

        repository.save(device);

        if (isNew) {
            auditService.log(username, "CREATE",
                    "MedicalDevice", device.getId());
        } else {
            auditService.log(username, "UPDATE",
                    "MedicalDevice", device.getId());
        }
    }

    @Override
    public List<MedicalDevice> getAllDevices() {
        return repository.findAll();
    }

    @Override
    public MedicalDevice getDeviceById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Device not found"));
    }

    @Override
    public void deleteDevice(Long id) {

        MedicalDevice device = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Device not found"));

        repository.deleteById(id);

        auditService.log(device.getCreatedBy(),
                "DELETE", "MedicalDevice", id);
    }
    
    @Override
    public List<MedicalDevice> searchDevices(String keyword) {

        if (keyword == null || keyword.isEmpty()) {
            return repository.findAll();
        }

        String lowerKeyword = keyword.toLowerCase();

        return repository.findAll().stream()
                .filter(device ->
                        (device.getDeviceName() != null &&
                         device.getDeviceName().toLowerCase().contains(lowerKeyword))

                     
                )
                .toList();
    }
}
