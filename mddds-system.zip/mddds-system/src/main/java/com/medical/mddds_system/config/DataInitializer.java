package com.medical.mddds_system.config;

import com.medical.mddds_system.entity.Role;
import com.medical.mddds_system.entity.User;
import com.medical.mddds_system.repository.RoleRepository;
import com.medical.mddds_system.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class DataInitializer implements CommandLineRunner {

    private final RoleRepository roleRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // 🔥 ADD THIS CONSTRUCTOR
    public DataInitializer(RoleRepository roleRepository,
                           UserRepository userRepository,
                           PasswordEncoder passwordEncoder) {
        this.roleRepository = roleRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {

        if (roleRepository.findByName("ADMIN").isEmpty()) {
            roleRepository.save(new Role(null, "ADMIN"));
        }

        if (roleRepository.findByName("STAFF").isEmpty()) {
            roleRepository.save(new Role(null, "STAFF"));
        }

        if (userRepository.findByUsername("admin").isEmpty()) {

            Role adminRole = roleRepository.findByName("ADMIN").get();

            User admin = new User();
            admin.setUsername("admin");
            admin.setEmail("admin@mddds.com");
            admin.setPassword(passwordEncoder.encode("Admin@123"));
            admin.setRoles(Set.of(adminRole));

            userRepository.save(admin);
        }
    }
}