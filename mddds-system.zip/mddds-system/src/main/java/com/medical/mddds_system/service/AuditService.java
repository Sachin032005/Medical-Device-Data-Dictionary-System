package com.medical.mddds_system.service;

public interface AuditService {

    void log(String username, String action,
             String entityName, Long entityId);
}
