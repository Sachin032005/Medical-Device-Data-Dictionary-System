package com.medical.mddds_system.service;

import com.medical.mddds_system.entity.DeviceType;
import com.medical.mddds_system.repository.DeviceTypeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeviceTypeServiceImpl implements DeviceTypeService {

    private final DeviceTypeRepository repository;

    public DeviceTypeServiceImpl(DeviceTypeRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<DeviceType> getAllDeviceTypes() {
        return repository.findAll();
    }

    @Override
    public DeviceType getDeviceTypeById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Device type not found"));
    }

    @Override
    public DeviceType saveDeviceType(DeviceType deviceType) {
        return repository.save(deviceType);
    }

    @Override
    public void deleteDeviceType(Long id) {
        repository.deleteById(id);
    }
}