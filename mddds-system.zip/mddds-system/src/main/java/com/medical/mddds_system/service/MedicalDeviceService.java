package com.medical.mddds_system.service;

import com.medical.mddds_system.entity.MedicalDevice;
import java.util.List;

public interface MedicalDeviceService {

    void saveDevice(MedicalDevice device, String username);

    List<MedicalDevice> getAllDevices();

    MedicalDevice getDeviceById(Long id);

    void deleteDevice(Long id);
    
    List<MedicalDevice> searchDevices(String keyword);
}