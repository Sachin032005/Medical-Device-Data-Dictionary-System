package com.medical.mddds_system.service;

import com.medical.mddds_system.entity.DeviceCategory;
import java.util.List;
import java.util.Optional;

public interface DeviceCategoryService {

    // Create or update category
    DeviceCategory saveCategory(DeviceCategory category);

    // Get all categories
    List<DeviceCategory> getAllCategories();

    // Get category by ID
    DeviceCategory getCategoryById(Long id);

    // Delete category
    void deleteCategory(Long id);

    // Optional additional useful methods
    Optional<DeviceCategory> getByDictionaryId(String dictionaryId);

    Optional<DeviceCategory> getByFieldName(String fieldName);
}