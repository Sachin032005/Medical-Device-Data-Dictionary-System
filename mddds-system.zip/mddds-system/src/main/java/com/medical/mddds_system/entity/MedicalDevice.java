package com.medical.mddds_system.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "medical_devices")
public class MedicalDevice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String deviceName;

    @ManyToOne
    @JoinColumn(name = "device_type_id")
    private DeviceType deviceType;

    private String manufacturerName;

    private String modelNumber;

    private String serialNumber;

    @Column(length = 2000)
    private String technicalSpecifications;

    @Column(length = 2000)
    private String intendedUse;

    private String regulatoryCertification;

    private String maintenanceSchedule;

    @Column(length = 2000)
    private String operationalInstructions;

    private String createdBy;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    public MedicalDevice() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getDeviceName() { return deviceName; }

    public void setDeviceName(String deviceName) { this.deviceName = deviceName; }

    public DeviceType getDeviceType() { return deviceType; }

    public void setDeviceType(DeviceType deviceType) { this.deviceType = deviceType; }

    public String getManufacturerName() { return manufacturerName; }

    public void setManufacturerName(String manufacturerName) { this.manufacturerName = manufacturerName; }

    public String getModelNumber() { return modelNumber; }

    public void setModelNumber(String modelNumber) { this.modelNumber = modelNumber; }

    public String getSerialNumber() { return serialNumber; }

    public void setSerialNumber(String serialNumber) { this.serialNumber = serialNumber; }

    public String getTechnicalSpecifications() { return technicalSpecifications; }

    public void setTechnicalSpecifications(String technicalSpecifications) { this.technicalSpecifications = technicalSpecifications; }

    public String getIntendedUse() { return intendedUse; }

    public void setIntendedUse(String intendedUse) { this.intendedUse = intendedUse; }

    public String getRegulatoryCertification() { return regulatoryCertification; }

    public void setRegulatoryCertification(String regulatoryCertification) { this.regulatoryCertification = regulatoryCertification; }

    public String getMaintenanceSchedule() { return maintenanceSchedule; }

    public void setMaintenanceSchedule(String maintenanceSchedule) { this.maintenanceSchedule = maintenanceSchedule; }

    public String getOperationalInstructions() { return operationalInstructions; }

    public void setOperationalInstructions(String operationalInstructions) { this.operationalInstructions = operationalInstructions; }

    public String getCreatedBy() { return createdBy; }

    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }

    public LocalDateTime getCreatedAt() { return createdAt; }

    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }

    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}