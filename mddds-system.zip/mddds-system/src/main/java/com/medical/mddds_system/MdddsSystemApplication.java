package com.medical.mddds_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MdddsSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MdddsSystemApplication.class, args);
	}

}
