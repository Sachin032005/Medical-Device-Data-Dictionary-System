package com.medical.mddds_system.config;

import com.medical.mddds_system.security.CustomUserDetailsService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    private final CustomUserDetailsService userDetailsService;

    public SecurityConfig(CustomUserDetailsService userDetailsService) {
        this.userDetailsService = userDetailsService;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider auth = new DaoAuthenticationProvider();
        auth.setUserDetailsService(userDetailsService);
        auth.setPasswordEncoder(passwordEncoder());
        return auth;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
            .csrf(csrf -> csrf.disable())
            .authenticationProvider(authenticationProvider())
            .authorizeHttpRequests(auth -> auth

                    .requestMatchers("/register", "/login", "/css/**").permitAll()

                    // DATA DICTIONARY (ADMIN + STAFF)
                    .requestMatchers("/admin/categories/**").hasAnyRole("ADMIN", "STAFF")

                    .requestMatchers("/staff/**").hasAnyRole("ADMIN", "STAFF")

                    .requestMatchers("/devices/add", "/devices/save", "/devices/edit/**", "/devices/delete/**")
                    .hasRole("ADMIN")

                    .requestMatchers("/devices/**")
                    .hasAnyRole("ADMIN", "STAFF")

                    .requestMatchers("/admin/audit/**").hasRole("ADMIN")

                    .requestMatchers("/admin/export/**").hasRole("ADMIN")

                    // OTHER ADMIN URLS
                    .requestMatchers("/admin/**").hasRole("ADMIN")

                    .anyRequest().authenticated()
            )
            .formLogin(form -> form
                    .loginPage("/login")
                    .loginProcessingUrl("/login")
                    .defaultSuccessUrl("/dashboard", true)
                    .permitAll()
            )
            .logout(logout -> logout
                    .logoutUrl("/logout")
                    .logoutSuccessUrl("/login?logout")
                    .permitAll()
            );

        return http.build();
    }
}