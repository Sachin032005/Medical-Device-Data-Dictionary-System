package com.medical.mddds_system.service.impl;

import com.medical.mddds_system.entity.DeviceCategory;
import com.medical.mddds_system.repository.DeviceCategoryRepository;
import com.medical.mddds_system.service.DeviceCategoryService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DeviceCategoryServiceImpl implements DeviceCategoryService {

    private final DeviceCategoryRepository repository;

    public DeviceCategoryServiceImpl(DeviceCategoryRepository repository) {
        this.repository = repository;
    }

    @Override
    public DeviceCategory saveCategory(DeviceCategory category) {
        return repository.save(category);
    }

    @Override
    public List<DeviceCategory> getAllCategories() {
        return repository.findAll();
    }

    @Override
    public DeviceCategory getCategoryById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Device Category not found with id: " + id));
    }

    @Override
    public void deleteCategory(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Optional<DeviceCategory> getByDictionaryId(String dictionaryId) {
        return repository.findByDictionaryId(dictionaryId);
    }

    @Override
    public Optional<DeviceCategory> getByFieldName(String fieldName) {
        return repository.findByFieldName(fieldName);
    }
}