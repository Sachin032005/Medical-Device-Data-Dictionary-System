package com.medical.mddds_system.controller;

import com.medical.mddds_system.entity.MedicalDevice;
import com.medical.mddds_system.service.MedicalDeviceService;
import com.medical.mddds_system.service.DeviceTypeService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/devices")
public class MedicalDeviceController {

    private final MedicalDeviceService service;
    private final DeviceTypeService deviceTypeService;

    public MedicalDeviceController(MedicalDeviceService service,
                                   DeviceTypeService deviceTypeService) {
        this.service = service;
        this.deviceTypeService = deviceTypeService;
    }

    // VIEW ALL DEVICES
    @GetMapping
    public String listDevices(@RequestParam(required = false) String keyword,
                              Model model) {

        if (keyword != null && !keyword.isEmpty()) {
            model.addAttribute("devices", service.searchDevices(keyword));
        } else {
            model.addAttribute("devices", service.getAllDevices());
        }

        model.addAttribute("keyword", keyword);
        return "device-list";
    }

    // SHOW ADD FORM
    @GetMapping("/add")
    public String showAddForm(Model model) {

        model.addAttribute("device", new MedicalDevice());
        model.addAttribute("deviceTypes", deviceTypeService.getAllDeviceTypes());

        return "device-form";
    }

    // SAVE DEVICE
    @PostMapping("/save")
    public String saveDevice(@ModelAttribute MedicalDevice device,
                             @RequestParam("deviceTypeId") Long deviceTypeId,
                             Authentication authentication) {

        String username = authentication.getName();

        device.setDeviceType(deviceTypeService.getDeviceTypeById(deviceTypeId));

        service.saveDevice(device, username);

        return "redirect:/devices";
    }

    // SHOW EDIT FORM
    @GetMapping("/edit/{id}")
    public String editDevice(@PathVariable Long id, Model model) {

        model.addAttribute("device", service.getDeviceById(id));
        model.addAttribute("deviceTypes", deviceTypeService.getAllDeviceTypes());

        return "device-form";
    }

    // DELETE DEVICE
    @GetMapping("/delete/{id}")
    public String deleteDevice(@PathVariable Long id) {

        service.deleteDevice(id);

        return "redirect:/devices";
    }
}