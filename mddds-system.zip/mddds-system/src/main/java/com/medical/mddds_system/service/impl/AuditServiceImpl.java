package com.medical.mddds_system.service.impl;

import com.medical.mddds_system.entity.AuditLog;
import com.medical.mddds_system.repository.AuditLogRepository;
import com.medical.mddds_system.service.AuditService;
import org.springframework.stereotype.Service;

@Service
public class AuditServiceImpl implements AuditService {

    private final AuditLogRepository repository;

    public AuditServiceImpl(AuditLogRepository repository) {
        this.repository = repository;
    }

    @Override
    public void log(String username, String action,
                    String entityName, Long entityId) {

        AuditLog log = new AuditLog(username, action, entityName, entityId);
        repository.save(log);
    }
}