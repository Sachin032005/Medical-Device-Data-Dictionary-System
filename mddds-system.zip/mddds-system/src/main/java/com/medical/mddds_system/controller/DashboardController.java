package com.medical.mddds_system.controller;

import com.medical.mddds_system.repository.MedicalDeviceRepository;
import com.medical.mddds_system.repository.DeviceCategoryRepository;
import com.medical.mddds_system.repository.UserRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    private final MedicalDeviceRepository deviceRepository;
    private final DeviceCategoryRepository categoryRepository;
    private final UserRepository userRepository;

    public DashboardController(MedicalDeviceRepository deviceRepository,
                               DeviceCategoryRepository categoryRepository,
                               UserRepository userRepository) {
        this.deviceRepository = deviceRepository;
        this.categoryRepository = categoryRepository;
        this.userRepository = userRepository;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {

        model.addAttribute("deviceCount", deviceRepository.count());
        model.addAttribute("categoryCount", categoryRepository.count());
        model.addAttribute("userCount", userRepository.count());

        return "dashboard";
    }
}