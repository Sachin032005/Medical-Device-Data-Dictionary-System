package com.medical.mddds_system.service;

import com.medical.mddds_system.entity.DeviceType;
import java.util.List;

public interface DeviceTypeService {

    List<DeviceType> getAllDeviceTypes();

    DeviceType getDeviceTypeById(Long id);

    DeviceType saveDeviceType(DeviceType deviceType);

    void deleteDeviceType(Long id);
}