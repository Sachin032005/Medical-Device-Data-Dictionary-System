package com.medical.mddds_system.controller;

import com.medical.mddds_system.repository.AuditLogRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/audit")
public class AuditController {

    private final AuditLogRepository repository;

    public AuditController(AuditLogRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public String viewAuditLogs(Model model) {
        model.addAttribute("logs", repository.findAll());
        return "audit-logs";
    }

    @PostMapping("/delete/{id}")
    public String deleteAuditLog(@PathVariable Long id) {
        repository.deleteById(id);
        return "redirect:/admin/audit";
    }
}