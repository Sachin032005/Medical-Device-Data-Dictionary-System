package com.medical.mddds_system.service;

import com.medical.mddds_system.dto.RegisterRequest;
import com.medical.mddds_system.entity.User;
import java.util.List;

public interface UserService {

    void registerUser(RegisterRequest request);

    List<User> getAllUsers();

    void toggleUserStatus(Long userId);

    void deleteUser(Long userId);
}